import { Router } from "express";
import { list } from "../controllers/audit.controller.js";
import { requirePermission } from "../middleware/permission.middleware.js";
import { validate } from "../middleware/validate.middleware.js";
import { auditQuerySchema } from "../validators/audit.validator.js";
import asyncHandler from "../utils/asyncHandler.js";
const r = Router();
r.get(
  "/",
  requirePermission("audit.view"),
  validate(auditQuerySchema, "query"),
  asyncHandler(list),
);
export default r;
