import { Router } from "express";
import * as c from "../controllers/companyCalendar.controller.js";
import { requirePermission as p } from "../middleware/permission.middleware.js";
import { validate } from "../middleware/validate.middleware.js";
import * as v from "../validators/companyCalendar.validator.js";
import asyncHandler from "../utils/asyncHandler.js";
const r = Router();
r.get(
  "/",
  p("calendar.view"),
  validate(v.listSchema, "query"),
  asyncHandler(c.list),
);
r.get("/upcoming", p("calendar.view"), asyncHandler(c.upcoming));
r.get("/day/:date", p("calendar.view"), asyncHandler(c.day));
r.post(
  "/",
  p("calendar.manage"),
  validate(v.holidaySchema),
  asyncHandler(c.create),
);
r.patch(
  "/:id",
  p("calendar.manage"),
  validate(v.updateSchema),
  asyncHandler(c.update),
);
r.delete("/:id", p("calendar.manage"), asyncHandler(c.cancel));
export default r;
