import env from "../config/env.js";
export function errorHandler(err, req, res, next) {
  let status = err.statusCode || 500,
    message = err.message || "Internal server error";
  if (err.code === "ER_DUP_ENTRY") {
    status = 409;
    message = "A record with that value already exists";
  }
  if (err.code?.startsWith("ER_")) {
    status = status === 500 ? 500 : status;
    if (status === 500)
      message = req.path.includes("attendance")
        ? "Unable to load attendance records"
        : req.path.includes("tasks")
          ? "Unable to update task. Please try again."
          : "Unable to complete the database request";
  }
  if (status === 500)
    console.error({
      timestamp: new Date().toISOString(),
      method: req.method,
      endpoint: req.originalUrl,
      userId: req.user?.id,
      employeeId: req.user?.employee_id,
      taskId: req.params?.id,
      status,
      errorCode: err.code,
      sqlMessage: err.sqlMessage,
      message: err.message,
      stack: err.stack,
    });
  res.status(status).json({
    success: false,
    message,
    ...(err.code && !err.code.startsWith("ER_") ? { code: err.code } : {}),
    ...(env.NODE_ENV === "development" && status === 500
      ? { debug: err.message }
      : {}),
  });
}
